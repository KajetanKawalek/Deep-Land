# Deep-Land
Multiplayer Ascii Sidescroller with Procedural Generation, (maybe MMO)

Originally a milczarzowy project but now i want to make this into a full blown game.

Features:
- Client-Server networking
- Procedural World Generation
- Structure Generation
- World Modification by player
- Player Skills and level
- Limited Item DataBase
- Anarchy
- Quests (maybe)

How to run: 
This is a visual studio project and there is no build yet.
Open this project with visual studio to run.
